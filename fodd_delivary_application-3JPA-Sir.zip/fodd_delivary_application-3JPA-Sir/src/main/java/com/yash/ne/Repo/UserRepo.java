package com.yash.ne.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.ne.Model.User;
@Repository
public interface UserRepo extends JpaRepository<User, Integer> {
        
	public User getById(String  emailId);
}
