package com.yash.ne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoddDelivaryApplication3JpaSirApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoddDelivaryApplication3JpaSirApplication.class, args);
	}

}
