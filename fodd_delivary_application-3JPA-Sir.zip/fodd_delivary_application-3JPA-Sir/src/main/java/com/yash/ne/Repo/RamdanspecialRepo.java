package com.yash.ne.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ne.Model.Ramdanspecial;

public interface RamdanspecialRepo extends JpaRepository<Ramdanspecial, Integer> {

}
