package spring_boot_restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoddDelivaryApplication3JpaSirApplicationTests {

	@Test
	void contextLoads() {
	}

}
